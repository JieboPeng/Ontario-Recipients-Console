/* File: Recipient.java
 * Author: Jiebo Peng
 * Date: 2023
 * Description: Demonstration of DAO Design Pattern, MVC Design Pattern
 */
package transferobjects;
/**
 * RecipientDTO class is used to define recipient.
 * @author Jiebo Peng
 */
public class RecipientDTO {
    /**
     * award ID of recipient in RecipientDTO class
     */
    private Integer awardID;
    /**
     * name of recipient in RecipientDTO class
     */
    private String name;
    /**
     * year of get award of RecipientDTO class
     */
    private Integer year;
    /**
     * city of recipient in RecipientDTO class
     */
    private String city;
    /**
     * category of award in RecipientDTO class
     */
    private String category;
 
    /**
     * Accessor for awardID.
     * @return String
     */
    public Integer getAwardID(){
    	return awardID;
    }
     /**
     * Mutator for AwardID
     * @param awardID the award ID
     */
    public void setAwardID(Integer awardID){
    	this.awardID = awardID;
    }
    /**
     * Accessor for name.
     * @return String
     */
    public String getName(){
    	return name;
    }
    /**
     * Mutator for name
     * @param name the name of the recipient
     */
    public void setName(String name){
    	this.name = name;
    }
    /**
     * Accessor for year.
     * @return String
     */
     public Integer getYear(){
    	return year;
    }
     /**
     * Mutator for year
     * @param year the year of get the award
     */ 
    public void setYear(Integer year){
    	this.year = year;
    }
    /**
     * Accessor for city.
     * @return String
     */
    public String getCity(){
    	return city;
    }
     /**
     * Mutator for city
     * @param city the city to give the award
     */ 
    public void setCity(String city){
    	this.city = city;
    }
    /**
     * Accessor for category.
     * @return String
     */
     public String getCategory(){
    	return category;
    }
     /**
     * Mutator for category
     * @param category the category of the award
     */ 
    public void setCategory(String category){
    	this.category = category;
    }
}
