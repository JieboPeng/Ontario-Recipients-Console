/* File: RecipientDao.java
 * Author: Jiebo Peng
 * Date: 2023
 * Description: Demonstration of DAO Design Pattern, MVC Design Pattern
 * References:
 * Ram N. (2013).  Data Access Object Design Pattern or DAO Pattern [blog] Retrieved from
 * http://ramj2ee.blogspot.in/2013/08/data-access-object-design-pattern-or.html
 */
package dataaccesslayer;

import java.util.List;

import transferobjects.RecipientDTO;
/**
 * this interface used for get all recipients, add recipient, and delete recipient
 * @author Jiebo Peng
 */
public interface RecipientDao {
        /**
         * abstract method for getting all recipients.
         * @return RecipientDTO
         */
	List<RecipientDTO> getAllRecipients();
    
        /**
         * abstract method for getting a recipient by awardId
         * @param awardID the award ID
         * @return RecipientDTO
         */
        RecipientDTO getRecipientByAwardId(Integer awardID);
        
        /**
         * abstract method for update recipient
         * @param recipient the object need to be updated.
         */
        void updateRecipient(RecipientDTO recipient);
        
        /**
         * abstract method for add recipient
         * @param recipient the object need to be added
         */
	void addRecipient(RecipientDTO recipient);
        
        /**
         * abstract method for delete recipient
         * @param recipient the object need to be deleted
         */
	void deleteRecipient(RecipientDTO recipient);
        
        /**
         * abstract method for print column type
         * @return String 
         */
        public String printColumnType();
        
        /**
         * abstract method for get column names
         * @return String
         */
        public  String getColumnNames();
}



	
	