
/* File: Launcher.java
 * Author: Jiebo Peng
 * Date: 2023
 * Description: Demonstration of DAO Design Pattern, MVC Design Pattern
 */

/**
 * the main entry of the project
 * @author Jiebo Peng
 */
public class Launcher {
    /**
     * the main method to test the demo method in SimleDemo class
     * @param args 
     */
	public static void main(String[] args) {
		 (new SimpleDemo()).demo();
	}
    }

	