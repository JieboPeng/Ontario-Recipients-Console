/* File: RecipientsBusinessLogic.java
 * Author: Jiebo Peng
 * Date: 2023
 * Description: Demonstration of DAO Design Pattern, MVC Design Pattern
 */
package businesslayer;

import java.util.List;
import dataaccesslayer.RecipientDao;
import dataaccesslayer.RecipientDaoImpl;
import transferobjects.RecipientDTO;

/**
 * Business logic class for managing recipients of awards
 * @author Jiebo Peng
 */
public class RecipientsBusinessLogic {
        /**
         * the max length of name
         */
	private static final int NAME_MAX_LENGTH = 30;
        /**
         * the max length of city
         */
	private static final int CITY_MAX_LENGTH = 30;
  
        /**
         * the max length of category
         */
        private static final int CATEGORY_MAX_LENGTH = 100;
        
	/**
         * a recipientDao reference of RecipientDao class
         */
	private RecipientDao recipientDao = null;
	/**
         * no argument constructor
         */
	public RecipientsBusinessLogic(){
		recipientDao = new RecipientDaoImpl();
	}
	/**
         * get all recipients information
         * @return RecipientDTO
         */
	public List<RecipientDTO> getAllRecipients(){
		return recipientDao.getAllRecipients();
	}
        
        /**
         * get a recipient information
         * @param awardID the award ID
         * @return RecipientDTO
         */
        public RecipientDTO getRecipient(Integer awardID){
		return recipientDao.getRecipientByAwardId(awardID);
	}
        
	/**
         *  add a recipient
         * @param recipient the object to be added
         * @throws businesslayer.ValidationException the exception information
         */
        public void addRecipient(RecipientDTO recipient) throws ValidationException{
		cleanRecipient(recipient);
		validateRecipient(recipient);
		recipientDao.addRecipient(recipient);
	}
        
        /**
        * update a Recipient information
        * @param recipient the object needed to be updated
        * @throws ValidationException the exception information
        */        
        public void updateRecipient(RecipientDTO recipient) throws ValidationException{
		cleanRecipient(recipient);
		validateRecipient(recipient);
		recipientDao.updateRecipient(recipient);
	}
        
        /**
         * print the column type
         * @return recipientDao
         */ 
         public String printColumnType(){
         return recipientDao.printColumnType();
         }
        
        /**
         * get the column names
         * @return recipientDao
         */ 
         public String getColumnName(){
         return recipientDao.getColumnNames();
         }
         
	/**
         * clean the recipient
         * @param recipient the object need to be cleaned
         */
	private void cleanRecipient(RecipientDTO recipient){
		if(recipient.getName() != null){ 
			recipient.setName(recipient.getName().trim());
		}
                if(recipient.getYear() != null){ 
			recipient.setYear(recipient.getYear());
		}
		if(recipient.getCity() != null){ 
			recipient.setCity(recipient.getCity().trim());
		}
                if(recipient.getCategory() != null){ 
			recipient.setCategory(recipient.getCategory().trim());
		}
                
	}
        
        /**
         * delete a recipient
         * @param recepient the object need to be deleted
         */
	public void deleteRecipient(RecipientDTO recepient){
		recipientDao.deleteRecipient(recepient);
	}
	/**
         * validate recipient
         * @param recepient the object need to be validated
         */
	private void validateRecipient(RecipientDTO recepient) throws ValidationException{
		validateString(recepient.getName(), "Name", NAME_MAX_LENGTH, true);
                validateInt(recepient.getYear(), "Year");
		validateString(recepient.getCity(), "City", CITY_MAX_LENGTH, true);
                validateString(recepient.getCategory(), "Category", CATEGORY_MAX_LENGTH, true);
	}
	/**
         * validate String
         * @param value fieldName maxLength isNullAllowed
         */
	private void validateString(String value, String fieldName, int maxLength, boolean isNullAllowed)
	    throws ValidationException{
		if(value == null && isNullAllowed){
		}
		else if(value == null && ! isNullAllowed){
		    throw new ValidationException(String.format("%s cannot be null", 
		    		fieldName));
		}
		else if(value.length() == 0){
			throw new ValidationException(String.format("%s cannot be empty or only whitespace", 
					fieldName));
		}
		else if(value.length() > maxLength){
			throw new ValidationException(String.format("%s cannot exceed %d characters", 
					fieldName, maxLength));
		}
	}
        /**
         * validate integer
         * @param value fieldName 
         */
	private void validateInt(int value, String fieldName)
	    throws ValidationException{
		if(value <= 0){
			throw new ValidationException(String.format("%s cannot be a negative number", 
					fieldName));
		}
	}
}
