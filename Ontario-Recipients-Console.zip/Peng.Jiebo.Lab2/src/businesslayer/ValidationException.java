/* File: ValidationException.java
 * Author: Stanley Pieda
 * Date: 2015
 * Description: Demonstration of DAO Design Pattern, MVC Design Pattern
 */
package businesslayer;
/**
 * the class extend Exception class, has overload method to generate information
 * @author annej
 */
public class ValidationException extends Exception {
	/**
         * no argument validationException method
         */
	public ValidationException(){
		super("Data not in valid format");
	}
	/**
         * one String argument validationException method
         * @param message   the message of exception
         */
	public ValidationException(String message){
		super(message);
	}
	/**
         * one String and one throwable argument validationException method
         * @param message  the message of exception
         * @param  throwable the object of Throwable class to be an argument
         */
	public ValidationException(String message, Throwable throwable){
		super(message, throwable);
	}
	/**
         * one throwable argument validationException method
         * @param  throwable the object of Throwable class to be an argument
         */
	public ValidationException(Throwable throwable){
		super(throwable);
	}
}
