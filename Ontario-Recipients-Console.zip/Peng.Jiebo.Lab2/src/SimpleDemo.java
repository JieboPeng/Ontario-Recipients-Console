/* File: SimpleDemo.java
 * Author: Jiebo Peng
 * Date: 2023
 * Description: Demonstration of DAO Design Pattern, MVC Design Pattern
 */
import businesslayer.RecipientsBusinessLogic;
import businesslayer.ValidationException;
import transferobjects.RecipientDTO;
import java.util.List;
/**
 * this class used to print all recipient, insert one record of recipient and 
 * delete a recipient.
 * @author Jiebo Peng
 */
public class SimpleDemo {
    /**
     * this method is used to test the created DAO Design pattern.
     */
    public void demo() {
        /**
         * this method test the created DAO design pattern
         */
        try {
            RecipientsBusinessLogic logic = new RecipientsBusinessLogic();
            List<RecipientDTO> list = null;
            RecipientDTO recipient = null;

            
            System.out.println("\nRecipients Table - Column Attributes:");
            System.out.println(logic.printColumnType());
            
            System.out.println("Printing Recipients");
            System.out.println(logic.getColumnName());
            list = logic.getAllRecipients();
            printRecipients(list);

            System.out.println("Printing One Recipient");
            System.out.println(logic.getColumnName());
            recipient = logic.getRecipient(1);
            printRecipient(recipient);
            System.out.println();

            System.out.println("Inserting One Recipient");
            System.out.println(logic.getColumnName());
            recipient = new RecipientDTO();
            recipient.setName("NameTestAdd");
            recipient.setYear(2023);
            recipient.setCity("CityTestAdd");
            recipient.setCategory("CategoryTestAdd");
            logic.addRecipient(recipient);
            list = logic.getAllRecipients();
            printRecipients(list);

            System.out.println("Updating last recipient");
            System.out.println(logic.getColumnName());
            Integer updatePrimaryKey = list.get(list.size() - 1).getAwardID();
            recipient = new RecipientDTO();
            recipient.setAwardID(updatePrimaryKey);
            recipient.setName("NameTestUpdate");
            recipient.setYear(2023);
            recipient.setCity("CityTestUpdate");
            recipient.setCategory("CategoryTestUpdate");
            logic.updateRecipient(recipient);
            list = logic.getAllRecipients();
            printRecipients(list);

            System.out.println("Deleting last recipient");
            System.out.println(logic.getColumnName());
            recipient = list.get(list.size() - 1);
            logic.deleteRecipient(recipient);
            list = logic.getAllRecipients();
            printRecipients(list);
        } catch (ValidationException e) {
            System.err.println(e.getMessage());
        } 
    }

	/**
         * print a recipient
         * @param recipient 
         */
	private static void printRecipient(RecipientDTO recipient){
	    	String output = String.format("%-8s\t%-32s\t%-8s\t%-8s\t%-8s\t",
	    			recipient.getAwardID().toString(),
	    			recipient.getName(),
                                recipient.getYear().toString(),
	    			recipient.getCity(),
                                recipient.getCategory());
	    	System.out.println(output);
	}
	   
        /**
         * print all recipients
         * @param recipients 
         */
	private static void printRecipients(List<RecipientDTO> recipients){
	    for(RecipientDTO recipient : recipients){
	    	printRecipient(recipient);
	    }
	    System.out.println();
	}
	

}
